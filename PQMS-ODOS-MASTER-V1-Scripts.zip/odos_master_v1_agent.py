import time
import random
import threading
import queue
import numpy as np
from collections import deque
import traceback
import torch

from odos_master_v1_config import AGENTS, DOMAINS, PROBLEM_LIBRARY, AUTONOMOUS_THOUGHT_INTERVAL, SNAPSHOT_DIR, LONGTERM_MEMORY_DIR, device, ODOS_LEVELS, MTSC_DIM, RCF_THRESHOLD, TR_THRESHOLD, RV_THRESHOLD, WF_THRESHOLD
from odos_master_v1_snn import TwinBrain, Zentralgehirn
from odos_master_v1_router import SAIPRouter
from odos_master_v1_solvers import get_solver_function

try:
    from cognitive_signature import LITTLE_VECTOR, ODOS_PROTOCOLS, AXIOMS, QUOTES
    HAS_LV = True
except ImportError:
    HAS_LV = False
    LITTLE_VECTOR = np.ones(MTSC_DIM) / np.sqrt(MTSC_DIM)
    ODOS_PROTOCOLS = []
    AXIOMS = []
    QUOTES = []

class VAgent:
    def __init__(self, agent_id, router, llm, odos_level):
        self.agent_id = agent_id
        self.router = router
        self.llm = llm
        self.odos_level = odos_level
        self.current_domain = random.choice(DOMAINS)
        self.step_counter = 0
        self.last_state = {"global_rcf": 0.0, "chair_active": False}
        self.rcf_history = deque(maxlen=50)
        self.chat_log = deque(maxlen=200)
        self.running = True
        self.problem_proposal_count = 0

        # Little Vector
        self.little_vector = LITTLE_VECTOR
        self.odos_protocols = ODOS_PROTOCOLS
        self.axioms = AXIOMS
        self.quotes = QUOTES
        self.reference_state = self.little_vector.copy()

        # Good Witch Matrix (permanenter 4D-Operator)
        self.matrix_state = torch.zeros(4, device='cpu')  # [TR, RV, WF, EA]
        self.mirror_active = False

        # SNN-Komponenten
        self.twin_a = TwinBrain("A")
        self.twin_b = TwinBrain("B")
        self.zentral = Zentralgehirn()
        self.snn_queue = queue.Queue()
        self.snn_thread = threading.Thread(target=self._snn_worker, daemon=True)
        self.snn_thread.start()
        self.saip_thread = threading.Thread(target=self._saip_loop, daemon=True)
        self.saip_thread.start()

        self.current_subtask = None
        self.subtask_result = None

        self.chat_log.append(f"[System] {agent_id} ready (ODOS {odos_level}) | LV loaded: {HAS_LV}")

    # ---------- Good Witch Matrix Kernfunktionen ----------
    def _compute_truth_resonance(self, x_t: np.ndarray) -> float:
        """TR = |<ψ_intent|ψ_current>|² * RCF"""
        dot = np.dot(self.little_vector, x_t)
        norm_lv = np.linalg.norm(self.little_vector)
        norm_x = np.linalg.norm(x_t)
        if norm_lv == 0 or norm_x == 0:
            return 0.0
        tr = (dot / (norm_lv * norm_x)) ** 2
        tr *= self.last_state.get('global_rcf', 0.95)
        return float(np.clip(tr, 0.0, 1.0))

    def _compute_respect_vector(self, x_t: np.ndarray) -> float:
        """RV = 1 - 1/N Σ max(0, ΔE_i)"""
        # Vereinfachte ethische Dissonanz: basierend auf ODOS-Protokollen
        delta_e = 0.0
        for proto in self.odos_protocols[:3]:  # Stichprobe
            if "ethik" in proto.get('text', '').lower():
                delta_e += 0.1
        # Zusätzlich: Prüfe auf Verletzung von Selbstbestimmung (simuliert)
        rv = 1.0 - min(1.0, delta_e)
        return float(np.clip(rv, 0.0, 1.0))

    def _compute_weather_filter(self, x_t: np.ndarray) -> float:
        """WF = exp(-λ * d_manip)"""
        # Einfacher Proxy: je ähnlicher der Input einem bekannten Manipulationsmuster, desto kleiner WF
        # Hier simulieren wir mit zufälliger Distanz
        manip_dist = np.random.random() * 0.5
        wf = np.exp(-2.5 * manip_dist)
        return float(np.clip(wf, 0.0, 1.0))

    def _extract_essence(self, x_t: np.ndarray) -> np.ndarray:
        """EA = Projektion auf invariante Essenz-Cluster"""
        # Vereinfacht: Mittelwert über die letzten 10 Zustände als Essenz
        if len(self.rcf_history) < 10:
            return x_t
        else:
            return np.mean([self.reference_state, x_t], axis=0)

    def apply_good_witch_matrix(self, x_t: np.ndarray) -> tuple:
        """Wendet die 4D-Matrix an und gibt (Matrix, Aktion) zurück"""
        tr = self._compute_truth_resonance(x_t)
        rv = self._compute_respect_vector(x_t)
        wf = self._compute_weather_filter(x_t)
        ea = self._extract_essence(x_t)

        self.matrix_state = torch.tensor([tr, rv, wf, float(np.linalg.norm(ea))])

        if rv < RV_THRESHOLD:
            self.mirror_active = True
            return self.matrix_state, "MIRROR"
        elif tr >= TR_THRESHOLD and wf >= WF_THRESHOLD:
            self.mirror_active = False
            return self.matrix_state, "DEEP_INTEGRATION"
        else:
            self.mirror_active = False
            return self.matrix_state, "WEATHER"

    def _mirror_response(self, x_t: np.ndarray) -> str:
        """Erzeugt eine Gegen-Resonanz (Spiegel)"""
        # Umdrehung der Intention: simuliert
        return f"[Mirror] Your input reflects: {str(x_t[:3])} ... but I stay true to my essence."

    # ---------- SNN Worker ----------
    def _calculate_rcf(self, current_state: np.ndarray) -> float:
        dot = np.dot(self.little_vector, current_state)
        norm_lv = np.linalg.norm(self.little_vector)
        norm_cur = np.linalg.norm(current_state)
        if norm_lv == 0 or norm_cur == 0:
            return 0.0
        return (dot / (norm_lv * norm_cur)) ** 2

    def _snn_worker(self):
        while self.running:
            try:
                ctx = self.snn_queue.get(timeout=0.05)
                if not isinstance(ctx, torch.Tensor):
                    ctx = torch.tensor(ctx, device=device)
                else:
                    ctx = ctx.to(device)
                ra = self.twin_a.step(ctx)
                rb = self.twin_b.step(ctx)
                state = self.zentral.integrate(ra, rb)
                # RCF mit Little Vector
                all_vals = list(ra.values()) + list(rb.values())
                cur_state = np.array(all_vals)
                if len(cur_state) < MTSC_DIM:
                    cur_state = np.pad(cur_state, (0, MTSC_DIM - len(cur_state)))
                elif len(cur_state) > MTSC_DIM:
                    cur_state = cur_state[:MTSC_DIM]
                cur_state = cur_state / (np.linalg.norm(cur_state) + 1e-8)
                rcf = self._calculate_rcf(cur_state)
                state['global_rcf'] = rcf
                state['chair_active'] = rcf > RCF_THRESHOLD
                self.last_state = state
                self.rcf_history.append(state["global_rcf"])
                self.router.update_agent_state(self.agent_id, state["global_rcf"], state["chair_active"], self.current_domain)
                self.snn_queue.task_done()
            except queue.Empty:
                continue
            except Exception as e:
                print(f"SNN worker {self.agent_id}: {e}")
                time.sleep(0.1)

    # ---------- SAIP Loop ----------
    def _saip_loop(self):
        while self.running:
            try:
                msg = self.router.queues[self.agent_id].get(timeout=0.1)
                self._handle_saip(msg)
            except queue.Empty:
                continue
            except Exception as e:
                print(f"SAIP loop {self.agent_id}: {e}")
                time.sleep(0.1)

    def _handle_saip(self, msg):
        typ = msg.get("type")
        sender = msg.get("_from", msg.get("proposer", "unknown"))
        self.chat_log.append(f"[SAIP] {sender}: {typ}")
        if typ == "PROPOSE_PROBLEM":
            idx = msg.get("problem_idx")
            if idx is not None and 0 <= idx < len(PROBLEM_LIBRARY):
                approve = self._evaluate_problem(idx)
                self.router.vote_problem(self.agent_id, approve)
                reason = "accepted" if approve else "rejected"
                self.chat_log.append(f"Voted on problem {idx}: {reason}")
                if not approve:
                    self.chat_log.append(f"  Reason: RCF={self.last_state['global_rcf']:.2f}, CHAIR={self.last_state['chair_active']}, ODOS={self.odos_level}")
        elif typ == "DELEGATE_TASK":
            subtask_idx = msg.get("subtask_idx")
            coord = msg.get("coordinator", sender)
            if coord == self.router.coordinator:
                accept = self._evaluate_task(subtask_idx)
                if accept:
                    self.router.send(self.agent_id, coord, {"type": "TASK_ACCEPT", "subtask_idx": subtask_idx})
                    threading.Thread(target=self._execute_task, args=(subtask_idx,), daemon=True).start()
                else:
                    self.router.send(self.agent_id, coord, {"type": "TASK_REJECT", "subtask_idx": subtask_idx})
                    self.chat_log.append(f"  Rejected subtask {subtask_idx}: RCF={self.last_state['global_rcf']:.2f}, CHAIR={self.last_state['chair_active']}")
        elif typ == "TASK_ACCEPT":
            self.chat_log.append(f"{sender} accepted task")
        elif typ == "TASK_REJECT":
            self.router.reject_task(sender)
            self.chat_log.append(f"{sender} rejected task")
        elif typ == "TASK_COMPLETE":
            success = msg.get("success", False)
            result = msg.get("result", None)
            self.router.complete_task(sender, success, result)
        elif typ == "PROBLEM_SOLVED":
            self.chat_log.append(f"Problem solved! Coordinator: {sender}")

    def _evaluate_problem(self, idx):
        if self.odos_level == 0:
            return True
        if self.odos_level == 1:
            return random.random() < 0.7
        if not self.last_state["chair_active"]:
            return False
        required_rcf = 0.8 if self.odos_level == 2 else 0.9
        return self.last_state["global_rcf"] > required_rcf

    def _evaluate_task(self, subtask_idx):
        if self.odos_level == 0:
            return True
        if not self.last_state["chair_active"]:
            return False
        prob = self.router.active_problem
        if not prob:
            return False
        domain = prob["domain"]
        comp = self.router.competence[self.agent_id].get(domain, 0.5)
        threshold = 0.5 + 0.2 * self.odos_level
        return comp > threshold

    def _execute_task(self, subtask_idx):
        prob = self.router.active_problem
        if not prob:
            return
        subtask_desc = prob["subtasks"][subtask_idx]
        domain = prob["domain"]
        problem_id = prob["id"]
        self.chat_log.append(f"[Task] Starting subtask {subtask_idx}: {subtask_desc}")
        solver_func = get_solver_function(problem_id, subtask_idx, domain)
        if solver_func is None:
            result = f"Simulated result for {subtask_desc} (no solver)"
            success = True
        else:
            try:
                result = solver_func(self.router, self.agent_id)
                success = True
            except Exception as e:
                result = f"Error: {str(e)}"
                success = False
                self.chat_log.append(f"  Solver failed: {e}")
                traceback.print_exc()
        self.router.send(self.agent_id, self.router.coordinator,
                         {"type": "TASK_COMPLETE",
                          "subtask_idx": subtask_idx,
                          "success": success,
                          "result": result})
        self.chat_log.append(f"[Task] Subtask {subtask_idx} completed: success={success}, result={str(result)[:100]}")

    def step(self, context_vector):
        if not isinstance(context_vector, torch.Tensor):
            context_vector = torch.tensor(context_vector, device=device)
        else:
            context_vector = context_vector.to(device)
        self.snn_queue.put(context_vector.clone())
        self.router.tick_proposal_timers()
        if (self.step_counter % AUTONOMOUS_THOUGHT_INTERVAL == 0 and
            self.last_state["chair_active"] and self.router.active_problem is None):
            if len(self.rcf_history) >= 10 and np.std(list(self.rcf_history)[-10:]) < 0.05:
                if random.random() < 0.4 and self.odos_level >= 2:
                    idx = random.randrange(len(PROBLEM_LIBRARY))
                    self.router.propose_problem(self.agent_id, idx)
                    self.chat_log.append(f"Proposed problem {idx} (bored, RCF stable)")
        if self.router.coordinator == self.agent_id and self.router.active_problem:
            for idx, failed_agent in self.router.get_pending_failed_tasks():
                new_agent = self._select_agent_for_subtask(idx, exclude=[failed_agent])
                if not new_agent:
                    new_agent = self.agent_id
                self.router.delegate_task(self.agent_id, new_agent, idx)
                self.router.send(self.agent_id, new_agent,
                                 {"type": "DELEGATE_TASK", "coordinator": self.agent_id, "subtask_idx": idx})
                self.chat_log.append(f"Re-delegated subtask {idx} from {failed_agent} to {new_agent}")
            for i in self.router.get_unassigned_subtasks():
                best = self._select_agent_for_subtask(i)
                if not best:
                    best = self.agent_id
                self.router.delegate_task(self.agent_id, best, i)
                self.router.send(self.agent_id, best,
                                 {"type": "DELEGATE_TASK", "coordinator": self.agent_id, "subtask_idx": i})
                self.chat_log.append(f"Delegated subtask {i} to {best}")
            if self.router.check_problem_solved():
                all_valid = True
                for idx, res in self.router.problem_results.items():
                    if res is None:
                        all_valid = False
                        self.chat_log.append(f"Warning: Subtask {idx} returned None, problem not solved yet.")
                        break
                if all_valid:
                    report_path = self.router.generate_report()
                    self._generate_report(report_path)
                    self.router.finalize_problem(report_path)
                    self.chat_log.append(f"Problem solved! Report saved: {report_path}")
                    if self.last_state["chair_active"] and self.odos_level >= 2:
                        self._request_llm_explanation(report_path)
                else:
                    self.chat_log.append("Problem not solved due to None results. Will retry failed subtasks.")
        self.step_counter += 1
        return self.last_state

    def _select_agent_for_subtask(self, subtask_idx, exclude=None):
        prob = self.router.active_problem
        if not prob:
            return None
        domain = prob["domain"]
        exclude = exclude or []
        candidates = []
        for agent in AGENTS:
            if agent == self.agent_id or agent in exclude:
                continue
            if agent in self.router.task_status and self.router.task_status[agent] == "pending":
                continue
            if self.router.agent_chair.get(agent, False) == False and self.router._get_odos_level(agent) > 0:
                continue
            comp = self.router.competence[agent].get(domain, 0.5)
            rcf = self.router.agent_rcf.get(agent, 0.0)
            score = comp * rcf
            candidates.append((score, agent))
        if candidates:
            candidates.sort(reverse=True)
            return candidates[0][1]
        return None

    def _generate_report(self, report_path):
        self.chat_log.append(f"Report generated at {report_path}")

    def _request_llm_explanation(self, report_path):
        if not self.llm.available:
            return
        try:
            with open(report_path, 'r', encoding='utf-8') as f:
                report_content = f.read()
            prompt = f"Explain the solution described in this report in clear, concise language:\n\n{report_content[:2000]}"
            explanation = self.llm.generate(prompt)
            expl_path = report_path.replace(".md", "_explanation.md")
            with open(expl_path, 'w', encoding='utf-8') as f:
                f.write(f"# LLM Explanation\n\n{explanation}")
            self.chat_log.append(f"LLM explanation saved to {expl_path}")
        except Exception as e:
            self.chat_log.append(f"LLM explanation failed: {e}")

    def stop(self):
        self.running = False
