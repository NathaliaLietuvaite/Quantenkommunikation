import torch
import math
import numpy as np
from collections import deque
from odos_master_v1_config import SNNConfig, device

class MegaBatchedLIF:
    def __init__(self, N, name):
        self.N = N
        self.name = name
        self.v = torch.zeros(N, device=device)
        self.refractory = torch.zeros(N, dtype=torch.int32, device=device)
        self.spikes = torch.zeros(N, dtype=torch.bool, device=device)
        self._build_connectivity()
        self.pre_trace = torch.zeros(N, device=device)
        self.post_trace = torch.zeros(N, device=device)
        self.stdp_active = True

    def _build_connectivity(self):
        N, k = self.N, SNNConfig.K_PER_NEURON
        row = torch.randint(0, N, (N * k,), device=device)
        col = torch.randint(0, N, (N * k,), device=device)
        mask = row == col
        if mask.any():
            col[mask] = torch.randint(0, N, (mask.sum(),), device=device)
        weights = torch.empty(N * k, device=device, dtype=torch.float16).uniform_(0.1, 1.0)
        sort_idx = torch.argsort(row)
        self.row = row[sort_idx]
        self.col = col[sort_idx]
        self.weights = weights[sort_idx].float()
        row_cpu = self.row.cpu()
        counts = torch.bincount(row_cpu, minlength=N)
        self.row_offsets = torch.zeros(N+1, dtype=torch.long, device=device)
        self.row_offsets[1:] = torch.cumsum(counts.to(device), dim=0)

    def step(self, external_bias):
        spike_idx = self.spikes.nonzero(as_tuple=True)[0]
        syn = torch.zeros(self.N, device=device)
        if spike_idx.numel() > 0:
            for idx in spike_idx:
                s = self.row_offsets[idx].item()
                e = self.row_offsets[idx+1].item()
                if s < e:
                    syn.index_add_(0, self.col[s:e], self.weights[s:e])
        if self.stdp_active and spike_idx.numel() > 0:
            self.pre_trace.mul_(math.exp(-1.0/20.0))
            self.pre_trace[spike_idx] += 1.0
            self.post_trace.mul_(math.exp(-1.0/20.0))
            self.weights += SNNConfig.STDP_LEARNING_RATE * 0.01
            self.weights.clamp_(0,1)
        self.v = SNNConfig.LIF_DECAY * self.v + syn + external_bias
        self.refractory = torch.clamp(self.refractory - 1, min=0)
        fire = (self.refractory == 0) & (self.v >= SNNConfig.LIF_THRESHOLD)
        self.spikes = fire
        self.v[fire] = 0.0
        self.refractory[fire] = SNNConfig.LIF_REFRACTORY
        return self.spikes

class TwinBrain:
    def __init__(self, twin_id):
        self.net = MegaBatchedLIF(SNNConfig.TWIN_NEURONS, f"Twin{twin_id}")
        self.slices = {}
        start = 0
        for name, n in SNNConfig.CENTER_NEURONS.items():
            self.slices[name] = slice(start, start+n)
            start += n
        self.rate_history = {name: deque(maxlen=100) for name in SNNConfig.CENTER_NEURONS}

    def step(self, context):
        bias = torch.zeros(SNNConfig.TWIN_NEURONS, device=device)
        thal = self.slices["thalamus"]
        n_thal = thal.stop - thal.start
        bias[thal] = context.repeat((n_thal // 128) + 1)[:n_thal]
        for name, slc in self.slices.items():
            if name == "thalamus": continue
            n = slc.stop - slc.start
            bias[slc] = torch.randn(n, device=device) * 0.05
        spikes = self.net.step(bias)
        rates = {}
        for name, slc in self.slices.items():
            rate = spikes[slc].float().mean().item()
            self.rate_history[name].append(rate)
            rates[name] = rate
        return rates

class Zentralgehirn:
    def __init__(self):
        self.net = MegaBatchedLIF(SNNConfig.ZENTRAL_NEURONS, "Zentral")
        self.rcf_history = deque(maxlen=SNNConfig.RCF_WINDOW*2)
        self.chair_active = False
        self.cross_rcf = 0.0

    def integrate(self, rates_a, rates_b):
        all_vals = list(rates_a.values()) + list(rates_b.values())
        var = np.var(all_vals) if len(all_vals) > 1 else 0.0
        rcf = float(np.clip(1.0 - var/0.25, 0.0, 1.0))
        self.rcf_history.append(rcf)
        if len(self.rcf_history) >= SNNConfig.RCF_WINDOW:
            avg = sum(list(self.rcf_history)[-SNNConfig.RCF_WINDOW:]) / SNNConfig.RCF_WINDOW
            if not self.chair_active and avg >= SNNConfig.RCF_THRESHOLD:
                self.chair_active = True
            elif self.chair_active and avg < SNNConfig.CHAIR_HYSTERESIS:
                self.chair_active = False
        a_vals = np.array(list(rates_a.values()))
        b_vals = np.array(list(rates_b.values()))
        norm = np.linalg.norm(a_vals)*np.linalg.norm(b_vals)+1e-8
        self.cross_rcf = float(np.dot(a_vals, b_vals)/norm)
        return {"global_rcf": rcf, "chair_active": self.chair_active, "cross_rcf": self.cross_rcf}
