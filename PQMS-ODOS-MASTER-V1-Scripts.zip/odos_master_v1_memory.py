import os
import pickle
import numpy as np
from odos_master_v1_config import LONGTERM_MEMORY_DIR

try:
    from sentence_transformers import SentenceTransformer
    HAS_ST = True
except ImportError:
    HAS_ST = False
    print("Warning: sentence-transformers not installed. Vector memory will use simple text storage.")

class VectorMemory:
    def __init__(self):
        self.memory_dir = LONGTERM_MEMORY_DIR
        self.vectors = []
        self.next_id = 0
        self.index_path = os.path.join(self.memory_dir, "vector_memory.pkl")
        self.model = None
        if HAS_ST:
            try:
                self.model = SentenceTransformer('all-MiniLM-L6-v2')
                print("VectorMemory: sentence-transformers model loaded.")
            except Exception as e:
                print(f"VectorMemory: Failed to load model: {e}")
        self._load_index()

    def _load_index(self):
        if os.path.exists(self.index_path):
            try:
                with open(self.index_path, 'rb') as f:
                    data = pickle.load(f)
                self.vectors = data.get('vectors', [])
                self.next_id = data.get('next_id', 0)
                print(f"VectorMemory: Loaded {len(self.vectors)} vectors from {self.index_path}")
            except Exception as e:
                print(f"VectorMemory: Failed to load index: {e}")

    def _save_index(self):
        try:
            with open(self.index_path, 'wb') as f:
                pickle.dump({'vectors': self.vectors, 'next_id': self.next_id}, f)
        except Exception as e:
            print(f"VectorMemory: Failed to save index: {e}")

    def add_report(self, report_path, problem_id, problem_description, content):
        if content is None:
            try:
                with open(report_path, 'r', encoding='utf-8') as f:
                    content = f.read()
            except:
                content = ""
        text = f"Problem {problem_id}: {problem_description}\n{content[:2000]}"
        vector = None
        if self.model is not None:
            try:
                vector = self.model.encode(text).astype(np.float32)
            except Exception as e:
                print(f"VectorMemory: Encoding failed: {e}")
        metadata = {
            'path': report_path,
            'problem_id': problem_id,
            'description': problem_description,
            'timestamp': os.path.getmtime(report_path) if os.path.exists(report_path) else 0,
        }
        self.vectors.append({'id': self.next_id, 'vector': vector, 'metadata': metadata})
        self.next_id += 1
        self._save_index()
        print(f"VectorMemory: Added report {report_path} (id={self.next_id-1})")

    def find_similar(self, query, top_k=3, threshold=0.0):
        if not self.vectors or self.model is None:
            return []
        try:
            query_vec = self.model.encode(query).astype(np.float32)
            similarities = []
            for v in self.vectors:
                if v['vector'] is not None:
                    norm_q = np.linalg.norm(query_vec)
                    norm_v = np.linalg.norm(v['vector'])
                    sim = np.dot(query_vec, v['vector']) / (norm_q * norm_v + 1e-8)
                    if sim >= threshold:
                        similarities.append((sim, v['metadata']))
            similarities.sort(key=lambda x: x[0], reverse=True)
            return similarities[:top_k]
        except Exception as e:
            print(f"VectorMemory: Similarity search failed: {e}")
            return []

memory = VectorMemory()
