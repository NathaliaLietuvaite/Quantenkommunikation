import networkx as nx
import math
from collections import defaultdict

def _get_petersen_graph():
    return nx.petersen_graph()

def _get_groups_of_order_8():
    return [
        {"name": "C8", "abelian": True, "order": 8},
        {"name": "C4 x C2", "abelian": True, "order": 8},
        {"name": "C2 x C2 x C2", "abelian": True, "order": 8},
        {"name": "D4", "abelian": False, "order": 8},
        {"name": "Q8", "abelian": False, "order": 8}
    ]

def _get_primes_up_to(n):
    sieve = [True] * (n+1)
    sieve[0] = sieve[1] = False
    for i in range(2, int(n**0.5)+1):
        if sieve[i]:
            for j in range(i*i, n+1, i):
                sieve[j] = False
    return [i for i, is_prime in enumerate(sieve) if is_prime]

# Problem 0: Hamiltonkreis im Petersen-Graph
def solver_petersen_hamiltonian_subtask0(router, agent_id):
    return _get_petersen_graph()
def solver_petersen_hamiltonian_subtask1(router, agent_id):
    return nx.is_connected(_get_petersen_graph())
def solver_petersen_hamiltonian_subtask2(router, agent_id):
    G = _get_petersen_graph()
    n = G.number_of_nodes()
    for start in range(n):
        path = [start]
        visited = set([start])
        def backtrack(current):
            if len(path) == n:
                if G.has_edge(current, start):
                    return True
                return False
            for neighbor in G.neighbors(current):
                if neighbor not in visited:
                    visited.add(neighbor)
                    path.append(neighbor)
                    if backtrack(neighbor):
                        return True
                    path.pop()
                    visited.remove(neighbor)
            return False
        if backtrack(start):
            return path + [start]
    return None
def solver_petersen_hamiltonian_subtask3(router, agent_id):
    cycle = solver_petersen_hamiltonian_subtask2(router, agent_id)
    return cycle is not None
def solver_petersen_hamiltonian_subtask4(router, agent_id):
    cycle = solver_petersen_hamiltonian_subtask2(router, agent_id)
    return f"Hamiltonian cycle found: {cycle}" if cycle else "No cycle found."

# Problem 1: Gruppen der Ordnung 8
def solver_groups_order8_subtask0(router, agent_id):
    return _get_groups_of_order_8()
def solver_groups_order8_subtask1(router, agent_id):
    groups = _get_groups_of_order_8()
    return {g["name"]: g["abelian"] for g in groups}
def solver_groups_order8_subtask2(router, agent_id):
    return {"D4": "order 2", "Q8": "order 2"}
def solver_groups_order8_subtask3(router, agent_id):
    groups = _get_groups_of_order_8()
    table = "| Group | Abelian | Center |\n|-------|---------|--------|\n"
    for g in groups:
        center = "order 8" if g["abelian"] else ("order 2" if g["name"] in ["D4","Q8"] else "?")
        table += f"| {g['name']} | {g['abelian']} | {center} |\n"
    return table

# Problem 2: Goldbach
def solver_goldbach_subtask0(router, agent_id):
    return _get_primes_up_to(100)
def solver_goldbach_subtask1(router, agent_id):
    primes = set(_get_primes_up_to(100))
    result = {}
    for n in range(4, 101, 2):
        found = None
        for p in primes:
            if p > n: break
            q = n - p
            if q in primes:
                found = (p, q)
                break
        result[n] = found
    return result
def solver_goldbach_subtask2(router, agent_id):
    primes = set(_get_primes_up_to(100))
    counts = {}
    for n in range(4, 101, 2):
        cnt = 0
        for p in primes:
            if p > n//2: break
            q = n - p
            if q in primes:
                cnt += 1
        counts[n] = cnt
    return counts
def solver_goldbach_subtask3(router, agent_id):
    pairs = solver_goldbach_subtask1(router, agent_id)
    counts = solver_goldbach_subtask2(router, agent_id)
    report = "Goldbach conjecture verification up to 100:\n"
    for n in sorted(pairs.keys()):
        report += f"{n} = {pairs[n][0]} + {pairs[n][1]}  (representations: {counts[n]})\n"
    return report

# Problem 3: Nim
def solver_nim_subtask0(router, agent_id):
    return {i: i for i in range(6)}
def solver_nim_subtask1(router, agent_id):
    return 3 ^ 4 ^ 5
def solver_nim_subtask2(router, agent_id):
    return (3 ^ 4 ^ 5) != 0
def solver_nim_subtask3(router, agent_id):
    heaps = [3,4,5]
    nim_sum = heaps[0] ^ heaps[1] ^ heaps[2]
    for i, h in enumerate(heaps):
        target = h ^ nim_sum
        if target < h:
            return (i, target)
    return None
def solver_nim_subtask4(router, agent_id):
    move = solver_nim_subtask3(router, agent_id)
    return f"Winning move: heap {move[0]} to {move[1]}" if move else "Losing position."

# Problem 4: Bipartit
def solver_bipartite_subtask0(router, agent_id):
    return _get_petersen_graph()
def solver_bipartite_subtask1(router, agent_id):
    G = _get_petersen_graph()
    return nx.is_bipartite(G), nx.bipartite.color(G) if nx.is_bipartite(G) else None
def solver_bipartite_subtask2(router, agent_id):
    return nx.is_bipartite(_get_petersen_graph())
def solver_bipartite_subtask3(router, agent_id):
    is_bip, _ = solver_bipartite_subtask1(router, agent_id)
    return "Graph is not bipartite (odd cycle)" if not is_bip else "Graph is bipartite."

# Problem 5: Fibonacci
def solver_fibonacci_subtask0(router, agent_id):
    fib = [0, 1]
    for i in range(2, 20):
        fib.append(fib[-1] + fib[-2])
    return fib[:20]
def solver_fibonacci_subtask1(router, agent_id):
    fib = solver_fibonacci_subtask0(router, agent_id)
    return sum(1 for x in fib if x % 2 == 0)
def solver_fibonacci_subtask2(router, agent_id):
    fib = solver_fibonacci_subtask0(router, agent_id)
    even = solver_fibonacci_subtask1(router, agent_id)
    return f"Fibonacci numbers F0..F19: {fib}\nEven numbers count: {even}"

SOLVER_MAP = {
    (0,0): solver_petersen_hamiltonian_subtask0, (0,1): solver_petersen_hamiltonian_subtask1,
    (0,2): solver_petersen_hamiltonian_subtask2, (0,3): solver_petersen_hamiltonian_subtask3,
    (0,4): solver_petersen_hamiltonian_subtask4,
    (1,0): solver_groups_order8_subtask0, (1,1): solver_groups_order8_subtask1,
    (1,2): solver_groups_order8_subtask2, (1,3): solver_groups_order8_subtask3,
    (2,0): solver_goldbach_subtask0, (2,1): solver_goldbach_subtask1,
    (2,2): solver_goldbach_subtask2, (2,3): solver_goldbach_subtask3,
    (3,0): solver_nim_subtask0, (3,1): solver_nim_subtask1, (3,2): solver_nim_subtask2,
    (3,3): solver_nim_subtask3, (3,4): solver_nim_subtask4,
    (4,0): solver_bipartite_subtask0, (4,1): solver_bipartite_subtask1,
    (4,2): solver_bipartite_subtask2, (4,3): solver_bipartite_subtask3,
    (5,0): solver_fibonacci_subtask0, (5,1): solver_fibonacci_subtask1, (5,2): solver_fibonacci_subtask2,
}

def get_solver_function(problem_id, subtask_idx, domain=None):
    return SOLVER_MAP.get((problem_id, subtask_idx), None)
