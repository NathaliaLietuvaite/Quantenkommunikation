#!/usr/bin/env python3
# extract_workspace.py
import re
import sys
from pathlib import Path

def extract_files(md_file, output_dir="."):
    with open(md_file, 'r', encoding='utf-8') as f:
        content = f.read()
    pattern = r"```(\w+)\n# PATH: (.*?)\n(.*?)```"
    matches = re.findall(pattern, content, re.DOTALL)
    out = Path(output_dir).resolve()
    for lang, rel_path_str, code in matches:
        target = out / rel_path_str
        target.parent.mkdir(parents=True, exist_ok=True)
        code_body = re.sub(r'^# PATH: .*?\n', '', code, count=1)
        with open(target, 'w', encoding='utf-8') as f:
            f.write(code_body)
        print(f"✅ {target}")
    print(f"Extraktion abgeschlossen. {len(matches)} Dateien.")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python extract_workspace.py <file.md>")
        sys.exit(1)
    extract_files(sys.argv[1])