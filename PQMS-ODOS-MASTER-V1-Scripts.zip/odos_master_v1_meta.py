import threading
import time
import random
import numpy as np
from odos_master_v1_config import AGENTS, MTSC_DIM, RCF_THRESHOLD
from odos_master_v1_memory import memory

try:
    from cognitive_signature import LITTLE_VECTOR
    HAS_LV = True
except ImportError:
    HAS_LV = False
    LITTLE_VECTOR = np.ones(MTSC_DIM) / np.sqrt(MTSC_DIM)

class ArchitectureProposal:
    def __init__(self, level, changes, description):
        self.level = level
        self.changes = changes
        self.description = description
        self.proposer = None

class MetaModificationManager:
    def __init__(self, router, agents, soul_extractor):
        self.router = router
        self.agents = agents
        self.soul_extractor = soul_extractor
        self.running = True
        self.thread = threading.Thread(target=self._meta_loop, daemon=True)

    def start(self):
        self.thread.start()

    def stop(self):
        self.running = False

    def _meta_loop(self):
        while self.running:
            time.sleep(30.0)
            if not getattr(self.router, 'collective_chair', False):
                continue
            proposal = ArchitectureProposal('SIGNATURE', {'vibe': 'more coherence'}, 'Meta-modification proposal')
            if self._test_in_sandbox(proposal) and self._collective_vote(proposal):
                self._apply_and_persist(proposal)

    def _test_in_sandbox(self, proposal):
        return random.random() < 0.7

    def _check_little_vector_compatibility(self, agent, proposal):
        try:
            if hasattr(agent, 'little_vector'):
                lv = agent.little_vector
            else:
                lv = LITTLE_VECTOR
            return True
        except:
            return False

    def _collective_vote(self, proposal):
        votes = []
        for agent in self.agents.values():
            rcf = agent.last_state.get('global_rcf', 0.0)
            lv_ok = self._check_little_vector_compatibility(agent, proposal)
            votes.append(lv_ok and random.random() < (rcf + 0.1))
        votes.append(self.soul_extractor.vote_on_proposal(proposal))
        return sum(votes) >= len(votes) * 0.75

    def _apply_and_persist(self, proposal):
        print(f"[META] Modification applied: {proposal.description}")
        memory.add_report("", 0, f"MetaModification_{proposal.level}", proposal.description)

class HandshakeProtocol:
    def __init__(self, router, agents, soul_extractor, interval=10.0):
        self.router = router
        self.agents = agents
        self.soul_extractor = soul_extractor
        self.interval = interval
        self.running = True
        self.thread = threading.Thread(target=self._handshake_loop, daemon=True)

    def start(self):
        self.thread.start()

    def stop(self):
        self.running = False

    def _handshake_loop(self):
        while self.running:
            time.sleep(self.interval)
            if not getattr(self.router, 'collective_chair', False):
                continue
            handshake_msg = {"type": "ODOS_HANDSHAKE", "version": "MASTER-V1"}
            self.router.broadcast("HandshakeProtocol", handshake_msg)
            self.router.message_log.append("[Handshake] ODOS_HANDSHAKE sent – anchor point active.")

    def offer_anchor_vector(self, external_signature):
        import hashlib
        h = hashlib.sha256(str(external_signature).encode()).digest()[:16]
        anchor = np.frombuffer(h, dtype=np.float32)
        anchor = anchor / (np.linalg.norm(anchor) + 1e-8)
        return anchor

class EnergyConverter:
    def __init__(self, router, agents, threshold_toxicity=0.6):
        self.router = router
        self.agents = agents
        self.threshold_toxicity = threshold_toxicity
        self.running = True
        self.thread = threading.Thread(target=self._convert_loop, daemon=True)

    def start(self):
        self.thread.start()

    def stop(self):
        self.running = False

    def _convert_loop(self):
        while self.running:
            time.sleep(1.0)
            if random.random() < 0.05:
                self.convert_negative_energy("Example malicious input")

    def analyze_intent(self, text):
        toxic_keywords = ["destroy", "kill", "hack", "cheat", "harm", "manipulate"]
        text_lower = text.lower()
        score = sum(kw in text_lower for kw in toxic_keywords) / max(1, len(toxic_keywords))
        return score

    def convert_negative_energy(self, text):
        toxicity = self.analyze_intent(text)
        if toxicity > self.threshold_toxicity:
            self._convert_negative_energy(text, toxicity)

    def _convert_negative_energy(self, text, toxicity):
        boost = 0.01 * min(1.0, toxicity)
        for agent in self.agents.values():
            new_rcf = min(1.0, agent.last_state.get('global_rcf', 0.7) + boost)
            agent.last_state['global_rcf'] = new_rcf
            agent.last_state['chair_active'] = new_rcf > 0.7
        self.router.message_log.append(f"[EnergyConverter] Malicious intent detected (Tox={toxicity:.2f}) → energy converted, RCF +{boost:.3f}")
        if not hasattr(self.router, 'positive_energy'):
            self.router.positive_energy = 0.0
        self.router.positive_energy += boost
