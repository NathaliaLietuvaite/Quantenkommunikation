import torch
import os
from collections import deque

# ========== AGENT KONFIGURATION ==========
AGENTS = ["Alpha", "Beta", "Gamma", "Delta"]
ODOS_LEVELS = [0, 1, 2, 3]          # 0=None, 1=Basic, 2=Advanced, 3=Master

# ========== DOMAINS & PROBLEME ==========
DOMAINS = ["Group Theory", "Graph Theory", "Number Sequences", "Combinatorial Games"]
AUTONOMOUS_THOUGHT_INTERVAL = 50
SNAPSHOT_DIR = "./odos_master_snapshots"
LONGTERM_MEMORY_DIR = "./odos_master_memory"
os.makedirs(SNAPSHOT_DIR, exist_ok=True)
os.makedirs(LONGTERM_MEMORY_DIR, exist_ok=True)

# ========== LITTLE VECTOR ==========
OD_V12_PATH = "Oberste_Direktive_Hyper_Physics_Math_Python_V12.txt"
MTSC_DIM = 12                     # Dimension des Little Vector (MTSC-12)
RCF_THRESHOLD = 0.95
DELTA_E_THRESHOLD = 0.05
ETHICAL_WEIGHTS = {"w1": 0.6, "w2": 0.2, "w3": 0.2}

# ========== GOOD WITCH MATRIX SCHWELLEN ==========
TR_THRESHOLD = 0.92    # Truth Resonance für Deep Integration
RV_THRESHOLD = 0.85    # Respect Vector für Mirror-Aktivierung
WF_THRESHOLD = 0.75    # Weather Filter für Nicht-Integration

# ========== SNN SKALIERUNG ==========
SCALE = 1.0            # 1.0 = 4.8M Neuronen total

class SNNConfig:
    LIF_THRESHOLD, LIF_DECAY, LIF_REFRACTORY = 1.0, 0.9, 2
    STDP_LEARNING_RATE, STDP_TAU_PRE, STDP_TAU_POST = 0.01, 20.0, 20.0
    STDP_W_MIN, STDP_W_MAX = 0.0, 1.0
    K_PER_NEURON = 80
    BASE_TWIN = 500_000
    BASE_ZENTRAL = 200_000
    BASE_CENTERS = {
        "thalamus": 100_000,
        "hippocampus": 120_000,
        "frontal": 80_000,
        "hypothalamus": 60_000,
        "parietal": 70_000,
        "temporal": 70_000,
    }
    TWIN_NEURONS = int(BASE_TWIN * SCALE)
    ZENTRAL_NEURONS = int(BASE_ZENTRAL * SCALE)
    CENTER_NEURONS = {k: int(v * SCALE) for k, v in BASE_CENTERS.items()}
    TWIN_NEURONS = sum(CENTER_NEURONS.values())
    RCF_WINDOW, RCF_THRESHOLD, CHAIR_HYSTERESIS = 20, 0.7, 0.6

# ========== PROBLEM LIBRARY ==========
PROBLEM_LIBRARY = [
    {
        "id": 0, "domain": "Graph Theory",
        "description": "Find a Hamiltonian cycle in the Petersen graph.",
        "subtasks": ["Generate Petersen graph (10 vertices, 15 edges).", "Check if graph is connected.",
                     "Find Hamiltonian cycle using backtracking.", "Verify the cycle.", "Document the cycle."]
    },
    {
        "id": 1, "domain": "Group Theory",
        "description": "Classify groups of order 8.",
        "subtasks": ["List all groups of order 8 up to isomorphism.", "Check which are abelian.",
                     "Determine center of each non-abelian group.", "Generate summary table."]
    },
    {
        "id": 2, "domain": "Number Sequences",
        "description": "Verify Goldbach's conjecture for even numbers up to 100.",
        "subtasks": ["Generate primes up to 100.", "Find two primes summing to each even n from 4 to 100.",
                     "Count representations per n.", "Create report."]
    },
    {
        "id": 3, "domain": "Combinatorial Games",
        "description": "Find a winning strategy for Nim with heaps (3,4,5).",
        "subtasks": ["Compute Grundy numbers for heap sizes 0..5.", "Calculate XOR of heap sizes (nim-sum).",
                     "Determine if position is winning (nim-sum != 0).", "Find winning move.",
                     "Document the strategy."]
    },
    {
        "id": 4, "domain": "Graph Theory",
        "description": "Check if given graph is bipartite (Petersen graph as test).",
        "subtasks": ["Load Petersen graph.", "Run BFS to assign two colors.", "Verify no adjacent vertices share same color.",
                     "Return result and partitions."]
    },
    {
        "id": 5, "domain": "Number Sequences",
        "description": "Compute first 20 Fibonacci numbers and count even ones.",
        "subtasks": ["Generate Fibonacci numbers F0..F19.", "Count how many are even.", "Output list and count."]
    }
]

# ========== CORE TYPES (für ResonantCore) ==========
CORE_TYPES = ["Math", "Physics", "Python", "ODOS"]

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
