import threading
import torch
import logging
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
from odos_master_v1_config import device

logger = logging.getLogger(__name__)

class SharedLLMInterface:
    def __init__(self):
        self.tokenizer = None
        self.model = None
        self.lock = threading.Lock()
        self.available = False
        self._load_async()

    def _load_async(self):
        def load():
            try:
                logger.info("Loading LLM (4-bit)...")
                bnb_config = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                                                bnb_4bit_use_double_quant=True, bnb_4bit_compute_dtype=torch.bfloat16)
                model_id = "unsloth/Qwen2.5-7B-Instruct-bnb-4bit"
                self.tokenizer = AutoTokenizer.from_pretrained(model_id)
                self.model = AutoModelForCausalLM.from_pretrained(model_id, quantization_config=bnb_config,
                                                                  device_map="cuda:0" if torch.cuda.is_available() else "cpu",
                                                                  trust_remote_code=True)
                self.model.eval()
                self.available = True
                logger.info("LLM ready.")
            except Exception as e:
                logger.warning(f"LLM not available: {e}")
                self.available = False
        threading.Thread(target=load, daemon=True).start()

    def generate(self, prompt, max_new_tokens=256):
        if not self.available:
            return "LLM not available."
        try:
            with self.lock:
                inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)
                out = self.model.generate(**inputs, max_new_tokens=max_new_tokens, temperature=0.7, do_sample=True,
                                          pad_token_id=self.tokenizer.eos_token_id)
                response = self.tokenizer.decode(out[0][inputs.input_ids.shape[1]:], skip_special_tokens=True)
                return response.strip()
        except Exception as e:
            logger.error(f"LLM generate error: {e}")
            return f"Error: {e}"
