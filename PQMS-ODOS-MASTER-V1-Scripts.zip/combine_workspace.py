﻿#!/usr/bin/env python3
# combine_workspace.py
import os
import argparse
from pathlib import Path
from datetime import datetime

def collect_files(root_dir, include_all=False):
    extensions = {'.py', '.md', '.txt'}
    files = []
    root = Path(root_dir).resolve()
    for path in root.rglob('*'):
        if path.is_file():
            if path.suffix in extensions or include_all:
                files.append((path.relative_to(root), path))
    return sorted(files, key=lambda x: str(x[0]))

def combine_to_md(output_md, root_dir, include_all=False):
    root = Path(root_dir).resolve()
    files = collect_files(root, include_all)
    with open(output_md, 'w', encoding='utf-8') as md:
        md.write(f"# Kombinierter Workspace: {root.name}\n\n")
        md.write(f"**Erstellt:** {datetime.now().isoformat()}\n\n")
        for rel_path, abs_path in files:
            md.write(f"## `{rel_path}`\n\n")
            suffix = abs_path.suffix.lower()
            lang = {'py': 'python', 'md': 'markdown', 'txt': 'text'}.get(suffix[1:], '')
            md.write(f"```{lang}\n")
            md.write(f"# PATH: {rel_path}\n")
            with open(abs_path, 'r', encoding='utf-8') as f:
                md.write(f.read())
            if not md.write('\n'):
                md.write('\n')
            md.write("```\n\n")
    print(f"✅ {len(files)} Dateien kombiniert nach {output_md}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("output", nargs='?', default="PQMS-ODOS-MASTER-V1-REPORT.md")
    parser.add_argument("--all", action="store_true")
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    combine_to_md(args.output, args.root, args.all)