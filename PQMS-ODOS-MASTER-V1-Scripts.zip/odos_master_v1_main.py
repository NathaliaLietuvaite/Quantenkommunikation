#!/usr/bin/env python3
import os
os.environ["TRANSFORMERS_VERBOSITY"] = "error"

import sys
import subprocess
import importlib
import warnings
warnings.filterwarnings("ignore", message="You passed `quantization_config`.*")

import torch

REQUIRED = ["numpy", "torch", "transformers", "accelerate", "bitsandbytes", "matplotlib"]
for pkg in REQUIRED:
    try:
        importlib.import_module(pkg.replace("-", "_"))
    except ImportError:
        subprocess.check_call([sys.executable, "-m", "pip", "install", pkg, "--quiet"])

from odos_master_v1_swarm import ODOSMasterSwarm
from odos_master_v1_gui import ODOSMasterGUI
from odos_master_v1_config import device, SCALE, SNNConfig, AGENTS, ODOS_LEVELS

def main():
    print("="*70)
    print("PQMS-ODOS-MASTER-V1 – The Good Witch's Mirror")
    print(f"Device: {device}")
    print(f"Scale: {SCALE}")
    twin = SNNConfig.TWIN_NEURONS
    zentral = SNNConfig.ZENTRAL_NEURONS
    pro_agent = 2 * twin + zentral
    total = pro_agent * len(AGENTS)
    print(f"Per agent: {pro_agent:,} neurons (2×{twin:,} Twin + {zentral:,} Zentral)")
    print(f"Total (4 agents): {total:,} neurons")
    odos_str = ", ".join([f"{a}={ODOS_LEVELS[i]}" for i, a in enumerate(AGENTS)])
    print(f"ODOS: {odos_str}")
    print("="*70)
    swarm = ODOSMasterSwarm()
    ODOSMasterGUI(swarm)

if __name__ == "__main__":
    main()
