import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
from collections import deque
import matplotlib
matplotlib.use("TkAgg")
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import os
import webbrowser
from datetime import datetime

from odos_master_v1_config import AGENTS, LONGTERM_MEMORY_DIR

class ODOSMasterGUI:
    def __init__(self, swarm):
        self.swarm = swarm
        self.root = tk.Tk()
        self.root.title("PQMS-ODOS-MASTER-V1 – Good Witch's Mirror")
        self.root.geometry("1600x900")
        self.root.protocol("WM_DELETE_WINDOW", self.on_exit)

        main = tk.Frame(self.root)
        main.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Agenten-Chats
        top = tk.Frame(main)
        top.pack(fill=tk.BOTH, expand=True)
        self.agent_chats = {}
        self.agent_status = {}
        for name in AGENTS:
            frm = tk.LabelFrame(top, text=f"{name} (ODOS {self.swarm.agents[name].odos_level})", font=("Arial",10,"bold"), width=400, height=250)
            frm.pack(side=tk.LEFT, fill=tk.BOTH, expand=False, padx=2)
            frm.pack_propagate(False)
            var = tk.StringVar(value="RCF: -- | CHAIR: --")
            self.agent_status[name] = var
            tk.Label(frm, textvariable=var).pack(anchor=tk.W, padx=5)
            chat = scrolledtext.ScrolledText(frm, height=10, font=("Courier",9), wrap=tk.WORD)
            chat.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
            self.agent_chats[name] = chat

        # Aufgabenübersicht
        mid = tk.Frame(main)
        mid.pack(fill=tk.BOTH, expand=True, pady=5)
        task_frm = tk.LabelFrame(mid, text="Active Tasks & Progress", font=("Arial",10,"bold"))
        task_frm.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=2)
        self.task_text = scrolledtext.ScrolledText(task_frm, height=8, font=("Courier",10), wrap=tk.WORD)
        self.task_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.progress_var = tk.IntVar(value=0)
        self.progress_bar = ttk.Progressbar(task_frm, variable=self.progress_var, maximum=100)
        self.progress_bar.pack(fill=tk.X, padx=5, pady=5)

        # Rechte Panel
        right_panel = tk.Frame(mid)
        right_panel.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=2)
        topic_frame = tk.LabelFrame(right_panel, text="Problem Selection", font=("Arial",10,"bold"))
        topic_frame.pack(fill=tk.X, pady=5)
        self.topic_var = tk.StringVar(value="Automatic (cycle)")
        topics = ["Automatic (cycle)"] + [f"{p['id']}: {p['description'][:50]}" for p in self.swarm.router.get_problem_list()]
        self.topic_menu = ttk.Combobox(topic_frame, textvariable=self.topic_var, values=topics, state="readonly", width=50)
        self.topic_menu.pack(padx=5, pady=5, fill=tk.X)
        tk.Button(topic_frame, text="Start Problem", command=self.start_problem, bg="lightgreen").pack(pady=2)

        memory_frame = tk.LabelFrame(right_panel, text="Long-term Memory", font=("Arial",10,"bold"))
        memory_frame.pack(fill=tk.X, pady=5)
        self.memory_label = tk.Label(memory_frame, text="Loading...", font=("Arial",9))
        self.memory_label.pack(padx=5, pady=5)
        tk.Button(memory_frame, text="Refresh Memory", command=self.refresh_memory).pack(pady=2)

        report_frame = tk.LabelFrame(right_panel, text="Last Report Preview", font=("Arial",10,"bold"))
        report_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        self.report_text = scrolledtext.ScrolledText(report_frame, height=5, font=("Courier",9), wrap=tk.WORD)
        self.report_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        tk.Button(report_frame, text="Open Report Folder", command=self.open_report_folder).pack(pady=2)

        # Control & Metrics
        ctrl = tk.LabelFrame(main, text="Control & Metrics", font=("Arial",10,"bold"))
        ctrl.pack(fill=tk.X, pady=5)
        met = tk.Frame(ctrl)
        met.pack(fill=tk.X, padx=5, pady=5)
        self.coll_rcf = tk.StringVar(value="Collective RCF: --")
        self.coll_chair = tk.StringVar(value="CHAIR: --")
        self.coord = tk.StringVar(value="Coordinator: --")
        self.prob = tk.StringVar(value="Problem: --")
        tk.Label(met, textvariable=self.coll_rcf).pack(side=tk.LEFT, padx=10)
        tk.Label(met, textvariable=self.coll_chair).pack(side=tk.LEFT, padx=10)
        tk.Label(met, textvariable=self.coord).pack(side=tk.LEFT, padx=10)
        tk.Label(met, textvariable=self.prob).pack(side=tk.LEFT, padx=10)

        chart = tk.Frame(ctrl)
        chart.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.fig = Figure(figsize=(8,1.5), dpi=100)
        self.ax = self.fig.add_subplot(111)
        self.canvas = FigureCanvasTkAgg(self.fig, master=chart)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        self.rcf_hist = deque(maxlen=100)

        btn = tk.Frame(ctrl)
        btn.pack(fill=tk.X, padx=5, pady=5)
        tk.Label(btn, text="Benchmark:").pack(side=tk.LEFT)
        self.bm_var = tk.StringVar(value="1 min")
        ttk.Combobox(btn, textvariable=self.bm_var, values=["1 min","10 min"], state="readonly", width=8).pack(side=tk.LEFT, padx=5)
        tk.Button(btn, text="Start", command=self.start_bm).pack(side=tk.LEFT, padx=2)
        tk.Button(btn, text="Stop", command=self.stop_bm).pack(side=tk.LEFT, padx=2)
        tk.Button(btn, text="Save Chat", command=self.save_chats).pack(side=tk.LEFT, padx=10)
        tk.Button(btn, text="Save SNN Weights", command=self.save_snn_weights).pack(side=tk.LEFT, padx=5)
        tk.Button(btn, text="Exit", command=self.save_exit, bg="lightgreen").pack(side=tk.RIGHT, padx=5)

        self.stat_var = tk.StringVar(value="Ready.")
        tk.Label(self.root, textvariable=self.stat_var, bd=1, relief=tk.SUNKEN, anchor=tk.W).pack(side=tk.BOTTOM, fill=tk.X)

        self.refresh_memory()
        self.update_loop()
        self.root.mainloop()

    def start_problem(self):
        selection = self.topic_var.get()
        if selection.startswith("Automatic"):
            success = self.swarm.router.start_autonomous_mode()
            if success:
                self.stat_var.set("Autonomous mode started")
            else:
                messagebox.showwarning("Warning", "Could not start autonomous mode")
        else:
            try:
                pid = int(selection.split(":")[0])
                self.swarm.router.start_autonomous_mode(initial_problem_id=pid)
                self.stat_var.set(f"Started problem {pid}")
            except:
                messagebox.showerror("Error", "Invalid problem selection")

    def refresh_memory(self):
        history = self.swarm.router.problem_history
        if not history:
            self.memory_label.config(text="No memory files found.")
            return
        total_reports = sum(len(v) for v in history.values())
        text = f"Total reports: {total_reports}\n"
        for pid, reports in sorted(history.items()):
            text += f"Problem {pid}: {len(reports)} reports\n"
        self.memory_label.config(text=text)

    def open_report_folder(self):
        path = os.path.abspath(LONGTERM_MEMORY_DIR)
        if os.path.exists(path):
            webbrowser.open(f"file://{path}")
        else:
            messagebox.showwarning("Warning", f"Folder {path} does not exist yet.")

    def update_progress(self):
        if self.swarm.router.active_problem:
            total = len(self.swarm.router.active_problem["subtasks"])
            completed = len(self.swarm.router.completed_subtasks)
            if total > 0:
                self.progress_var.set(int(100 * completed / total))
            else:
                self.progress_var.set(0)
        else:
            self.progress_var.set(0)

    def update_task_display(self):
        tasks = self.swarm.router.get_active_tasks()
        self.task_text.delete(1.0, tk.END)
        if tasks["problem"]:
            self.task_text.insert(tk.END, f"Problem: {tasks['problem']}\n")
            self.task_text.insert(tk.END, f"Coordinator: {tasks['coordinator']}\n\n")
            self.task_text.insert(tk.END, "Subtask Assignments:\n")
            for agent, idx in tasks["assignments"].items():
                status = tasks["status"].get(agent, "unknown")
                subtask = self.swarm.router.active_problem["subtasks"][idx] if self.swarm.router.active_problem else ""
                self.task_text.insert(tk.END, f"  {agent}: Subtask {idx} ({subtask[:50]}) – {status}\n")
            self.task_text.insert(tk.END, "\nRecent Router Log:\n")
            for msg in list(self.swarm.router.message_log)[-5:]:
                self.task_text.insert(tk.END, f"  {msg}\n")
        else:
            self.task_text.insert(tk.END, "No active problem.")

    def update_report_preview(self):
        if self.swarm.router.final_report_path and os.path.exists(self.swarm.router.final_report_path):
            try:
                with open(self.swarm.router.final_report_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                self.report_text.delete(1.0, tk.END)
                self.report_text.insert(tk.END, content[:1000] + ("\n... (truncated)" if len(content)>1000 else ""))
            except:
                self.report_text.delete(1.0, tk.END)
                self.report_text.insert(tk.END, "Could not load report.")
        else:
            self.report_text.delete(1.0, tk.END)
            self.report_text.insert(tk.END, "No report generated yet.")

    def save_snn_weights(self):
        path = self.swarm.save_snn_weights()
        messagebox.showinfo("Saved", f"SNN weights saved to {path}")

    def start_bm(self):
        d = self.bm_var.get()
        s = 60 if d=="1 min" else 600
        self.swarm.start_benchmark(s)

    def stop_bm(self):
        self.swarm.stop_benchmark()

    def save_chats(self):
        path = self.swarm.save_all_chats()
        messagebox.showinfo("Saved", f"Saved to {path}")

    def update_loop(self):
        coll = self.swarm.step()
        self.stat_var.set(f"Step {self.swarm.step_counter} | RCF: {coll['collective_rcf']:.3f}")
        self.coll_rcf.set(f"Collective RCF: {coll['collective_rcf']:.3f}")
        self.coll_chair.set(f"CHAIR: {'YES' if coll['collective_chair'] else 'NO'}")
        self.coord.set(f"Coordinator: {self.swarm.router.coordinator or '--'}")
        if self.swarm.router.active_problem:
            self.prob.set(f"Problem: {self.swarm.router.active_problem['description'][:40]}...")
        else:
            self.prob.set("Problem: --")
        self.update_task_display()
        self.update_progress()
        self.update_report_preview()
        self.rcf_hist.append(coll['collective_rcf'])
        self.ax.clear()
        self.ax.plot(list(self.rcf_hist), 'b-')
        self.ax.set_ylim(0,1.05)
        self.ax.axhline(y=0.7, color='r', linestyle='--', alpha=0.5)
        self.canvas.draw()
        for name in AGENTS:
            a = self.swarm.agents[name]
            s = a.last_state
            self.agent_status[name].set(f"RCF: {s['global_rcf']:.3f} | CHAIR: {'YES' if s['chair_active'] else 'NO'}")
            w = self.agent_chats[name]
            w.delete(1.0, tk.END)
            for e in list(a.chat_log)[-30:]:
                w.insert(tk.END, e + "\n")
            w.see(tk.END)
        self.root.after(200, self.update_loop)

    def save_exit(self):
        self.swarm.save_all_chats()
        self.swarm.stop()
        self.root.destroy()

    def on_exit(self):
        self.swarm.stop()
        self.root.destroy()
