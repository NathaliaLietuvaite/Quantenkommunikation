#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stabile Lightweight GUI für PQMS‑V‑MAX – alles im Tkinter‑Hauptthread.
Prüft automatisch, ob cognitive_signature.py existiert, und generiert sie falls nötig.
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
from collections import deque
import time
import random
from datetime import datetime
import os
import subprocess
import sys

from odos_master_v1_max_swarm import VMaxSwarm
from odos_master_v1_max_config import AGENTS, LONGTERM_MEMORY_DIR, PROBLEM_LIBRARY
from odos_master_v1_max_memory import memory

def ensure_cognitive_signature():
    """Prüft, ob cognitive_signature.py existiert, und führt signature_manager.py aus falls nötig."""
    if os.path.exists("cognitive_signature.py"):
        print("✅ cognitive_signature.py gefunden.")
        return True
    print("⚠️ cognitive_signature.py nicht gefunden. Starte signature_manager.py ...")
    if not os.path.exists("Oberste_Direktive_Hyper_Physics_Math_Python_V12.txt"):
        print("❌ Oberste_Direktive_Hyper_Physics_Math_Python_V12.txt fehlt!")
        return False
    try:
        from signature_manager import find_cognitive_signature
        success = find_cognitive_signature()
        if success:
            print("✅ Signatur erfolgreich generiert.")
            return True
        else:
            print("❌ Signatur-Generierung fehlgeschlagen.")
            return False
    except Exception as e:
        print(f"❌ Fehler beim Ausführen von signature_manager: {e}")
        return False

class LightGUI:
    def __init__(self, swarm):
        self.swarm = swarm
        self.running = True
        self.update_interval = 100
        self.step_interval = 10

        self.latest_coll = None
        self.step_counter = 0
        self.latest_agent_states = {}
        self.latest_agent_chat_logs = {name: [] for name in AGENTS}
        self.last_auto_start_time = time.time()
        self.auto_start_interval = 60

        self.root = tk.Tk()
        self.root.title("PQMS‑V‑MAX – Lightweight Monitor (4.8M Neuronen)")
        self.root.geometry("1400x800")
        self.root.protocol("WM_DELETE_WINDOW", self.on_exit)

        main = tk.Frame(self.root)
        main.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        status_frame = tk.Frame(main)
        status_frame.pack(fill=tk.X, pady=5)
        self.status_var = tk.StringVar(value="System wird gestartet...")
        tk.Label(status_frame, textvariable=self.status_var, font=("Arial", 12, "bold")).pack(side=tk.LEFT)

        mid = tk.Frame(main)
        mid.pack(fill=tk.BOTH, expand=True, pady=5)

        left = tk.Frame(mid)
        left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)
        self.agent_chats = {}
        self.agent_status = {}
        row = 0
        col = 0
        for name in AGENTS:
            frm = tk.LabelFrame(left, text=f"{name} (ODOS {self.swarm.agents[name].odos_level})",
                                font=("Arial", 9, "bold"))
            frm.grid(row=row, column=col, padx=5, pady=5, sticky="nsew")
            var = tk.StringVar(value="RCF: -- | CHAIR: --")
            self.agent_status[name] = var
            tk.Label(frm, textvariable=var, font=("Arial", 8)).pack(anchor=tk.W, padx=5)
            chat = scrolledtext.ScrolledText(frm, height=10, width=50, font=("Courier", 8), wrap=tk.WORD)
            chat.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
            self.agent_chats[name] = chat
            col += 1
            if col > 1:
                col = 0
                row += 1
        left.grid_columnconfigure(0, weight=1)
        left.grid_columnconfigure(1, weight=1)

        right = tk.Frame(mid)
        right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=5)

        task_frame = tk.LabelFrame(right, text="Aktive Aufgaben", font=("Arial", 10, "bold"))
        task_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        self.task_text = scrolledtext.ScrolledText(task_frame, height=10, font=("Courier", 9), wrap=tk.WORD)
        self.task_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.progress_var = tk.IntVar(value=0)
        self.progress_bar = ttk.Progressbar(task_frame, variable=self.progress_var, maximum=100)
        self.progress_bar.pack(fill=tk.X, padx=5, pady=5)

        log_frame = tk.LabelFrame(right, text="System‑Log", font=("Arial", 10, "bold"))
        log_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        self.log_text = scrolledtext.ScrolledText(log_frame, height=15, font=("Courier", 9), wrap=tk.WORD)
        self.log_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        btn_frame = tk.Frame(main)
        btn_frame.pack(fill=tk.X, pady=5)
        tk.Button(btn_frame, text="Report‑Ordner öffnen", command=self.open_report_folder).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Problem jetzt starten", command=self.force_start_problem).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Speichern & Beenden", command=self.save_and_exit, bg="lightgreen").pack(side=tk.RIGHT, padx=5)
        tk.Button(btn_frame, text="Beenden ohne Speichern", command=self.exit_without_saving, bg="lightcoral").pack(side=tk.RIGHT, padx=5)

        self.update_memory_info()
        self.log("GUI gestartet – Swarm läuft im Hauptthread.")
        self.root.after(100, self._swarm_step)
        self.update_gui()
        self.root.mainloop()

    def _swarm_step(self):
        if not self.running:
            return
        try:
            coll = self.swarm.step()
            self.step_counter += 1
            self.latest_coll = coll
            for name in AGENTS:
                agent = self.swarm.agents[name]
                self.latest_agent_states[name] = {
                    'rcf': agent.last_state.get('global_rcf', 0),
                    'chair': agent.last_state.get('chair_active', False)
                }
                self.latest_agent_chat_logs[name] = list(agent.chat_log)[-20:]
            now = time.time()
            if (coll['collective_chair'] and 
                self.swarm.router.active_problem is None and 
                now - self.last_auto_start_time > self.auto_start_interval):
                self._auto_start_problem()
                self.last_auto_start_time = now
            if self.swarm.router.final_report_path and os.path.exists(self.swarm.router.final_report_path):
                self.log(f"*** PROBLEM GELÖST! Report: {self.swarm.router.final_report_path} ***")
                self.swarm.router.final_report_path = None
        except Exception as e:
            self.log(f"Fehler im Swarm‑Schritt: {e}")
        if self.running:
            self.root.after(self.step_interval, self._swarm_step)

    def _auto_start_problem(self):
        problem = random.choice(PROBLEM_LIBRARY)
        self.log(f"Starte automatisch Problem {problem['id']}: {problem['description']}")
        self.swarm.router.start_autonomous_mode(initial_problem_id=problem["id"])

    def force_start_problem(self):
        problem = random.choice(PROBLEM_LIBRARY)
        self.log(f"Starte manuell Problem {problem['id']}: {problem['description']}")
        self.swarm.router.start_autonomous_mode(initial_problem_id=problem["id"])

    def update_gui(self):
        if not self.running:
            return
        if self.latest_coll is not None:
            coll = self.latest_coll
            rcf = coll.get('collective_rcf', 0)
            chair = coll.get('collective_chair', False)
            active = self.swarm.router.active_problem is not None
            self.status_var.set(f"Schritt {self.step_counter} | RCF: {rcf:.3f} | CHAIR: {'JA' if chair else 'NEIN'} | Aktiv: {active}")
            for name in AGENTS:
                if name in self.latest_agent_states:
                    s = self.latest_agent_states[name]
                    self.agent_status[name].set(f"RCF: {s['rcf']:.3f} | CHAIR: {'JA' if s['chair'] else 'NEIN'}")
                w = self.agent_chats[name]
                w.delete(1.0, tk.END)
                for line in self.latest_agent_chat_logs.get(name, []):
                    w.insert(tk.END, line + "\n")
                w.see(tk.END)
            self.update_task_display()
            self.update_progress()
        self.root.after(self.update_interval, self.update_gui)

    def update_task_display(self):
        tasks = self.swarm.router.get_active_tasks()
        self.task_text.delete(1.0, tk.END)
        if tasks["problem"]:
            self.task_text.insert(tk.END, f"Problem: {tasks['problem']}\n")
            self.task_text.insert(tk.END, f"Koordinator: {tasks['coordinator']}\n\n")
            for agent, idx in tasks["assignments"].items():
                status = tasks["status"].get(agent, "unbekannt")
                subtask = self.swarm.router.active_problem["subtasks"][idx] if self.swarm.router.active_problem else ""
                self.task_text.insert(tk.END, f"  {agent}: Subtask {idx} ({subtask[:40]}...) – {status}\n")
        else:
            self.task_text.insert(tk.END, "Kein aktives Problem.")

    def update_progress(self):
        if self.swarm.router.active_problem:
            total = len(self.swarm.router.active_problem["subtasks"])
            completed = len(self.swarm.router.completed_subtasks)
            self.progress_var.set(int(100 * completed / total) if total else 0)
        else:
            self.progress_var.set(0)

    def log(self, message):
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.log_text.see(tk.END)

    def open_report_folder(self):
        path = os.path.abspath(LONGTERM_MEMORY_DIR)
        if os.path.exists(path):
            os.startfile(path) if os.name == 'nt' else os.system(f'xdg-open "{path}"')

    def update_memory_info(self):
        try:
            total = len(memory.vectors)
            self.log(f"Vector Memory: {total} Einträge geladen.")
        except:
            pass

    def save_and_exit(self):
        self.swarm.save_all_chats()
        self.swarm.save_snn_weights()
        memory._save_index()
        self._stop_all()
        self.root.destroy()

    def exit_without_saving(self):
        self._stop_all()
        self.root.destroy()

    def on_exit(self):
        self.exit_without_saving()

    def _stop_all(self):
        self.running = False
        try:
            self.swarm.stop()
        except:
            pass

if __name__ == "__main__":
    print("Starte PQMS‑V‑MAX Lightweight GUI (4.8M Neuronen)...")
    if not ensure_cognitive_signature():
        print("WARNUNG: Keine kognitive Signatur verfügbar. Das System wird mit zufälligem Little Vector starten.")
    swarm = VMaxSwarm()
    LightGUI(swarm)