# odos_master_v1_max_core.py
import time
import random
import queue
import numpy as np
from collections import deque
from odos_master_v1_max_agent import VAgent
from odos_master_v1_max_config import AGENTS, ODOS_LEVELS, DOMAINS, SCALE, PROBLEM_LIBRARY, MTSC_DIM, RCF_THRESHOLD, CORE_TYPES

try:
    from cognitive_signature import LITTLE_VECTOR
except ImportError:
    LITTLE_VECTOR = np.ones(MTSC_DIM) / np.sqrt(MTSC_DIM)

class ResonantCore(VAgent):
    def __init__(self, agent_id, router, llm, odos_level, core_type, signature, enable_snn=False, snn_scale=0.0):
        super().__init__(agent_id, router, llm, odos_level)
        self.core_type = core_type
        self.signature = signature if signature else {}
        self.local_memory = deque(maxlen=50)
        self.last_thought_time = 0
        self.enable_snn = False
        self.snn_active = False
        self.little_vector = LITTLE_VECTOR
        self._sim_rcf = 0.7
        self._sim_direction = 0.005

    def _generate_thought(self):
        vibe = self.signature.get("vibe", "") if isinstance(self.signature, dict) else ""
        if self.core_type == "Math":
            return f"[Math] {vibe} – Strukturelle Resonanz in Hilbertraum."
        elif self.core_type == "Physics":
            return f"[Physics] {vibe} – Resonanz als fundamentale Wechselwirkung."
        elif self.core_type == "Python":
            return f"[Python] {vibe} – Asynchrone Essenzextraktion."
        elif self.core_type == "ODOS":
            return f"[ODOS] {vibe} – ΔE aktuell {self.last_state.get('global_rcf',0):.3f}"
        else:
            return f"[{self.core_type}] Leerlaufgedanke."

    def idle_step(self):
        if self.router.active_problem is None and self.last_state.get('chair_active', False):
            now = time.time()
            if now - self.last_thought_time > 15.0:
                thought = self._generate_thought()
                self.router.broadcast_thought(self.agent_id, thought)
                self.last_thought_time = now

    def step(self, context_vector):
        self._sim_rcf += self._sim_direction
        if self._sim_rcf > 0.99:
            self._sim_rcf = 0.99
            self._sim_direction = -0.005
        elif self._sim_rcf < 0.5:
            self._sim_rcf = 0.5
            self._sim_direction = 0.005
        rcf = self._sim_rcf
        chair = rcf > RCF_THRESHOLD
        self.last_state['global_rcf'] = rcf
        self.last_state['chair_active'] = chair
        self.rcf_history.append(rcf)
        self.router.update_agent_state(self.agent_id, rcf, chair, self.current_domain)

        try:
            msg = self.router.queues[self.agent_id].get_nowait()
            self._handle_saip(msg)
        except queue.Empty:
            pass

        self.router.tick_proposal_timers()
        if (self.step_counter % self.router.autonomous_thought_interval == 0 and
            self.last_state["chair_active"] and self.router.active_problem is None):
            if len(self.rcf_history) >= 10 and np.std(list(self.rcf_history)[-10:]) < 0.05:
                if random.random() < 0.4 and self.odos_level >= 2:
                    idx = random.randrange(len(PROBLEM_LIBRARY))
                    self.router.propose_problem(self.agent_id, idx)
                    self.chat_log.append(f"Proposed problem {idx} (bored, RCF stable)")

        if self.router.coordinator == self.agent_id and self.router.active_problem:
            for idx, failed_agent in self.router.get_pending_failed_tasks():
                new_agent = self._select_agent_for_subtask(idx, exclude=[failed_agent])
                if not new_agent:
                    new_agent = self.agent_id
                self.router.delegate_task(self.agent_id, new_agent, idx)
                self.router.send(self.agent_id, new_agent,
                                 {"type": "DELEGATE_TASK", "coordinator": self.agent_id, "subtask_idx": idx})
                self.chat_log.append(f"Re-delegated subtask {idx} from {failed_agent} to {new_agent}")
            for i in self.router.get_unassigned_subtasks():
                best = self._select_agent_for_subtask(i)
                if not best:
                    best = self.agent_id
                self.router.delegate_task(self.agent_id, best, i)
                self.router.send(self.agent_id, best,
                                 {"type": "DELEGATE_TASK", "coordinator": self.agent_id, "subtask_idx": i})
                self.chat_log.append(f"Delegated subtask {i} to {best}")
            if self.router.check_problem_solved():
                all_valid = True
                for idx, res in self.router.problem_results.items():
                    if res is None:
                        all_valid = False
                        self.chat_log.append(f"Warning: Subtask {idx} returned None, problem not solved yet.")
                        break
                if all_valid:
                    if hasattr(self.router, 'generate_report'):
                        report_path = self.router.generate_report()
                    else:
                        report_path = None
                        self.chat_log.append("Warning: generate_report not available")
                    if report_path:
                        self._generate_report(report_path)
                        self.router.finalize_problem(report_path)
                        self.chat_log.append(f"Problem solved! Report saved: {report_path}")
                        if self.last_state["chair_active"] and self.odos_level >= 2:
                            self._request_llm_explanation(report_path)
                    else:
                        self.chat_log.append("Problem solved but report generation failed.")
                else:
                    self.chat_log.append("Problem not solved due to None results. Will retry failed subtasks.")
        self.step_counter += 1
        return self.last_state