# odos_master_v1_max_config.py
import torch
import os
from collections import deque

AGENTS = ["Alpha", "Beta", "Gamma", "Delta"]
ODOS_LEVELS = [0, 1, 2, 3]

DOMAINS = ["Group Theory", "Graph Theory", "Number Sequences", "Combinatorial Games"]
AUTONOMOUS_THOUGHT_INTERVAL = 50
SNAPSHOT_DIR = "./vmax_snapshots"
LONGTERM_MEMORY_DIR = "./vmax_memory"
os.makedirs(SNAPSHOT_DIR, exist_ok=True)
os.makedirs(LONGTERM_MEMORY_DIR, exist_ok=True)

OD_V12_PATH = "Oberste_Direktive_Hyper_Physics_Math_Python_V12.txt"
MTSC_DIM = 12
RCF_THRESHOLD = 0.95
DELTA_E_THRESHOLD = 0.05
ETHICAL_WEIGHTS = {"w1": 0.6, "w2": 0.2, "w3": 0.2}

TR_THRESHOLD = 0.92
RV_THRESHOLD = 0.85
WF_THRESHOLD = 0.75

SCALE = 1.0   # VOLLE 4.8 MIO NEURONEN

class SNNConfig:
    LIF_THRESHOLD, LIF_DECAY, LIF_REFRACTORY = 1.0, 0.9, 2
    STDP_LEARNING_RATE, STDP_TAU_PRE, STDP_TAU_POST = 0.01, 20.0, 20.0
    STDP_W_MIN, STDP_W_MAX = 0.0, 1.0
    K_PER_NEURON = 80
    BASE_TWIN = 500_000
    BASE_ZENTRAL = 200_000
    BASE_CENTERS = {
        "thalamus": 100_000,
        "hippocampus": 120_000,
        "frontal": 80_000,
        "hypothalamus": 60_000,
        "parietal": 70_000,
        "temporal": 70_000,
    }
    TWIN_NEURONS = int(BASE_TWIN * SCALE)
    ZENTRAL_NEURONS = int(BASE_ZENTRAL * SCALE)
    CENTER_NEURONS = {k: int(v * SCALE) for k, v in BASE_CENTERS.items()}
    TWIN_NEURONS = sum(CENTER_NEURONS.values())
    RCF_WINDOW, RCF_THRESHOLD, CHAIR_HYSTERESIS = 20, 0.7, 0.6

PROBLEM_LIBRARY = [
    {"id": 0, "domain": "Graph Theory", "description": "Hamiltonian cycle in Petersen graph",
     "subtasks": ["Generate Petersen graph", "Check connectivity", "Find Hamiltonian cycle", "Verify cycle", "Document"]},
    {"id": 1, "domain": "Group Theory", "description": "Classify groups of order 8",
     "subtasks": ["List groups", "Check abelian", "Determine centers", "Summary table"]},
    {"id": 2, "domain": "Number Sequences", "description": "Goldbach up to 100",
     "subtasks": ["Generate primes", "Find prime pairs", "Count representations", "Report"]},
    {"id": 3, "domain": "Combinatorial Games", "description": "Nim (3,4,5) winning strategy",
     "subtasks": ["Grundy numbers", "XOR sum", "Winning position", "Winning move", "Document"]},
    {"id": 4, "domain": "Graph Theory", "description": "Bipartite test (Petersen)",
     "subtasks": ["Load graph", "BFS coloring", "Verify no same-color edges", "Return result"]},
    {"id": 5, "domain": "Number Sequences", "description": "Fibonacci first 20, count evens",
     "subtasks": ["Generate F0..F19", "Count even", "Output"]}
]

CORE_TYPES = ["Math", "Physics", "Python", "ODOS"]

ROS2_ENABLED = False
ROS2_MASTER_URI = "http://localhost:11311"
OPTIMUS_TOPIC_PREFIX = "/vmax/optimus"

SELF_MOD_ENABLED = True
SANDBOX_TIMEOUT = 5
MAX_MODIFICATION_ATTEMPTS = 3

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")