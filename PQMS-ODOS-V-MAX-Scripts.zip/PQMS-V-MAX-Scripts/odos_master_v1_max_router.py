# odos_master_v1_max_router.py
import queue
import threading
import numpy as np
from collections import deque
from datetime import datetime
import os
import json
import glob
import hashlib

from odos_master_v1_max_config import AGENTS, DOMAINS, PROBLEM_LIBRARY, LONGTERM_MEMORY_DIR, SNAPSHOT_DIR
from odos_master_v1_max_memory import memory

try:
    from cognitive_signature import LITTLE_VECTOR
    LV_BYTES = LITTLE_VECTOR.tobytes()
    LITTLE_VECTOR_HASH = hashlib.sha256(LV_BYTES).hexdigest()
except ImportError:
    LITTLE_VECTOR_HASH = "00000000000000000000000000000000"

class SAIPRouter:
    def __init__(self):
        self.queues = {a: queue.Queue() for a in AGENTS}
        self.agent_rcf = {a: 0.0 for a in AGENTS}
        self.agent_chair = {a: False for a in AGENTS}
        self.competence = {a: {d: 1.0 for d in DOMAINS} for a in AGENTS}
        self.active_problem = None
        self.coordinator = None
        self.task_assignments = {}
        self.task_status = {}
        self.task_results = {}
        self.completed_subtasks = set()
        self.problem_proposals = {}
        self.proposal_timers = {}
        self.message_log = deque(maxlen=200)
        self.lock = threading.Lock()
        self.auto_mode = False
        self.problem_cycle_index = 0
        self.problem_history = {}
        self._load_problem_history()
        self.problem_results = {}
        self.final_report_path = None
        self.benchmark_mode = False
        self.autonomous_thought_interval = 50
        self.little_vector_hash = LITTLE_VECTOR_HASH

    def set_benchmark_mode(self, enabled):
        with self.lock:
            self.benchmark_mode = enabled
            if enabled:
                self.message_log.append("Benchmark mode active – no new problems will be started")
            else:
                self.message_log.append("Benchmark mode ended")

    def send(self, from_agent, to_agent, msg):
        with self.lock:
            if to_agent in self.queues:
                msg["_from"] = from_agent
                self.queues[to_agent].put(msg)
                self.message_log.append(f"{from_agent} -> {to_agent}: {msg.get('type')}")

    def broadcast(self, from_agent, msg):
        with self.lock:
            for a in AGENTS:
                if a != from_agent:
                    m = msg.copy()
                    m["_from"] = from_agent
                    self.queues[a].put(m)
            self.message_log.append(f"{from_agent} -> ALL: {msg.get('type')}")

    def update_agent_state(self, agent, rcf, chair, domain):
        with self.lock:
            self.agent_rcf[agent] = rcf
            self.agent_chair[agent] = chair
            self.competence[agent][domain] = min(2.0, self.competence[agent][domain] + 0.001)

    def get_collective_state(self):
        with self.lock:
            rcfs = list(self.agent_rcf.values())
            coll_rcf = float(np.mean(rcfs)) if rcfs else 0.0
            chair_cnt = sum(self.agent_chair.values())
            coll_chair = (chair_cnt >= 2) and coll_rcf > 0.7
            return {"collective_rcf": coll_rcf, "collective_chair": coll_chair}

    def get_active_tasks(self):
        with self.lock:
            return {"problem": self.active_problem["description"] if self.active_problem else None,
                    "coordinator": self.coordinator,
                    "assignments": self.task_assignments.copy(),
                    "status": self.task_status.copy()}

    def propose_problem(self, agent, idx):
        with self.lock:
            if self.benchmark_mode:
                return False
            if self.active_problem:
                return False
            self.problem_proposals = {agent: idx}
            self.proposal_timers[agent] = 0
            self.message_log.append(f"{agent} proposed problem {idx}")
            for a in AGENTS:
                if a != agent:
                    self.queues[a].put({"type":"PROPOSE_PROBLEM","problem_idx":idx,"proposer":agent})
            return True

    def vote_problem(self, agent, approve):
        with self.lock:
            if not self.problem_proposals:
                return False
            if approve:
                proposer = list(self.problem_proposals.keys())[0]
                idx = self.problem_proposals[proposer]
                self.active_problem = PROBLEM_LIBRARY[idx]
                self.coordinator = proposer
                self.task_assignments.clear()
                self.task_status.clear()
                self.task_results.clear()
                self.completed_subtasks.clear()
                self.problem_results.clear()
                memory_text = self._load_memory_for_problem(idx)
                self.message_log.append(f"*** CONSENSUS: Problem '{self.active_problem['description']}' active. Coordinator: {self.coordinator} ***")
                if memory_text:
                    self.message_log.append(f"Loaded {len(memory_text)} chars of long-term memory for problem {idx}.")
                self.problem_proposals.clear()
                self.proposal_timers.clear()
                return True
            return False

    def tick_proposal_timers(self):
        with self.lock:
            to_remove = []
            for p, t in self.proposal_timers.items():
                self.proposal_timers[p] = t+1
                if t > 200:
                    to_remove.append(p)
            for p in to_remove:
                if p in self.problem_proposals:
                    del self.problem_proposals[p]
                del self.proposal_timers[p]

    def delegate_task(self, coordinator, target, subtask_idx):
        with self.lock:
            if coordinator != self.coordinator or not self.active_problem:
                return False
            if target in self.task_status and self.task_status[target] == "pending":
                return False
            if subtask_idx in self.completed_subtasks:
                return False
            self.task_assignments[target] = subtask_idx
            self.task_status[target] = "pending"
            self.message_log.append(f"{coordinator} delegated subtask {subtask_idx} to {target}")
            return True

    def reject_task(self, agent):
        with self.lock:
            if agent in self.task_status and self.task_status[agent] == "pending":
                self.task_status[agent] = "rejected"
                self.message_log.append(f"{agent} rejected task")

    def complete_task(self, agent, success, result=None):
        with self.lock:
            if agent not in self.task_status:
                return
            subtask = self.task_assignments.get(agent)
            if subtask is None:
                return
            if success:
                self.task_status[agent] = "completed"
                self.completed_subtasks.add(subtask)
                self.task_results[agent] = result
                self.problem_results[subtask] = result
                self.message_log.append(f"{agent} completed task successfully: {str(result)[:50]}")
                domain = self.active_problem["domain"]
                self.competence[agent][domain] = min(2.0, self.competence[agent][domain] + 0.05)
                if agent in self.task_assignments:
                    del self.task_assignments[agent]
            else:
                self.task_status[agent] = "failed"
                self.message_log.append(f"{agent} failed task")
                domain = self.active_problem["domain"]
                self.competence[agent][domain] = max(0.1, self.competence[agent][domain] - 0.02)
                if agent in self.task_assignments:
                    del self.task_assignments[agent]

    def check_problem_solved(self):
        with self.lock:
            if not self.active_problem:
                return False
            if len(self.completed_subtasks) == len(self.active_problem["subtasks"]):
                if any(v is None for v in self.problem_results.values()):
                    self.message_log.append("Problem not solved: some subtasks returned None")
                    return False
                self.message_log.append(f"*** PROBLEM SOLVED: {self.active_problem['description']} ***")
                return True
            return False

    def finalize_problem(self, report_path):
        with self.lock:
            self.final_report_path = report_path
            self.active_problem = None
            self.coordinator = None
            self.task_assignments.clear()
            self.task_status.clear()
            self.task_results.clear()
            self.completed_subtasks.clear()
            self.problem_results.clear()

    def get_pending_failed_tasks(self):
        with self.lock:
            pending = []
            for agent, status in self.task_status.items():
                if status in ("failed", "rejected"):
                    idx = self.task_assignments.get(agent)
                    if idx is not None and idx not in self.completed_subtasks:
                        pending.append((idx, agent))
            return pending

    def get_unassigned_subtasks(self):
        with self.lock:
            if not self.active_problem:
                return []
            assigned = set(self.task_assignments.values())
            return [i for i in range(len(self.active_problem["subtasks"])) if i not in assigned and i not in self.completed_subtasks]

    def _load_problem_history(self):
        if not os.path.exists(LONGTERM_MEMORY_DIR):
            return
        for file in glob.glob(os.path.join(LONGTERM_MEMORY_DIR, "report_problem_*.md")):
            basename = os.path.basename(file)
            parts = basename.split('_')
            if len(parts) >= 3 and parts[0] == "report" and parts[1] == "problem":
                try:
                    pid = int(parts[2])
                    self.problem_history.setdefault(pid, []).append(file)
                except:
                    pass

    def _load_memory_for_problem(self, problem_idx):
        problem_desc = PROBLEM_LIBRARY[problem_idx]["description"]
        similar = memory.find_similar(problem_desc, top_k=2, threshold=0.5)
        memory_text = ""
        if similar:
            memory_text += "# Similar past reports (vector memory)\n\n"
            for score, meta in similar:
                memory_text += f"## Score {score:.3f}: {meta['description']}\n"
                try:
                    with open(meta['path'], 'r', encoding='utf-8') as f:
                        content = f.read()
                    memory_text += content[:1000] + "\n...\n\n"
                except:
                    pass
        reports = self.problem_history.get(problem_idx, [])
        if reports:
            reports.sort(key=lambda f: os.path.getmtime(f), reverse=True)
            memory_text += "# Recent filesystem reports\n\n"
            for i, rpath in enumerate(reports[:3]):
                try:
                    with open(rpath, 'r', encoding='utf-8') as f:
                        content = f.read()
                    memory_text += f"## Report {i+1} (from {os.path.basename(rpath)})\n{content[:1000]}\n\n"
                except:
                    continue
        return memory_text

    def select_problem_auto(self):
        if not PROBLEM_LIBRARY:
            return None
        problem = PROBLEM_LIBRARY[self.problem_cycle_index % len(PROBLEM_LIBRARY)]
        self.problem_cycle_index += 1
        return problem

    def start_autonomous_mode(self, initial_problem_id=None):
        with self.lock:
            if self.benchmark_mode:
                self.message_log.append("Cannot start problem in benchmark mode")
                return False
            if self.active_problem:
                return False
            if initial_problem_id is not None:
                problem = next((p for p in PROBLEM_LIBRARY if p["id"] == initial_problem_id), None)
            else:
                problem = self.select_problem_auto()
            if problem is None:
                return False
            domain = problem["domain"]
            best_agent = max(AGENTS, key=lambda a: self.competence[a].get(domain, 0.0) * self.agent_rcf.get(a, 0.0))
            idx = problem["id"]
            self.propose_problem(best_agent, idx)
            return True

    def get_problem_list(self):
        return [{"id": p["id"], "description": p["description"]} for p in PROBLEM_LIBRARY]

    def generate_report(self):
        if not self.active_problem:
            return None
        problem = self.active_problem
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"report_problem_{problem['id']}_{timestamp}.md"
        filepath = os.path.join(LONGTERM_MEMORY_DIR, filename)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(f"# Report: {problem['description']}\n")
            f.write(f"**Domain:** {problem['domain']}\n")
            f.write(f"**Coordinator:** {self.coordinator}\n")
            f.write(f"**Date:** {datetime.now().isoformat()}\n\n")
            f.write("## Subtask Results\n\n")
            for agent, subtask_idx in self.task_assignments.items():
                status = self.task_status.get(agent, "unknown")
                result = self.task_results.get(agent, "no result")
                subtask_text = problem["subtasks"][subtask_idx]
                f.write(f"### {agent} (ODOS {self._get_odos_level(agent)}): {subtask_text}\n")
                f.write(f"- **Status:** {status}\n")
                f.write(f"- **Result:** {result}\n\n")
            f.write("## Overall Solution\n\n")
            all_results = [self.problem_results.get(i) for i in range(len(problem["subtasks"]))]
            f.write("Collected results per subtask:\n")
            for i, res in enumerate(all_results):
                f.write(f"{i}: {res}\n")
            f.write("\n---\n*Generated by PQMS-V-MAX Swarm*\n")
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        memory.add_report(filepath, problem["id"], problem["description"], content)
        self.final_report_path = filepath
        return filepath

    def broadcast_thought(self, from_agent, thought):
        with self.lock:
            self.message_log.append(f"[THOUGHT] {from_agent}: {thought}")

    def _get_odos_level(self, agent):
        idx = AGENTS.index(agent) if agent in AGENTS else 0
        from odos_master_v1_max_config import ODOS_LEVELS
        return ODOS_LEVELS[idx]