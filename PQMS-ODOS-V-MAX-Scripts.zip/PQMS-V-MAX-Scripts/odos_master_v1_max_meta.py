# odos_master_v1_max_meta.py
import threading
import time
import random
import numpy as np
from odos_master_v1_max_config import AGENTS, MTSC_DIM, RCF_THRESHOLD, SELF_MOD_ENABLED
from odos_master_v1_max_memory import memory

try:
    from cognitive_signature import LITTLE_VECTOR
    HAS_LV = True
except ImportError:
    HAS_LV = False
    LITTLE_VECTOR = np.ones(MTSC_DIM) / np.sqrt(MTSC_DIM)

class ArchitectureProposal:
    def __init__(self, level, changes, description, code=None):
        self.level = level
        self.changes = changes
        self.description = description
        self.code = code
        self.proposer = None

class MetaModificationManager:
    def __init__(self, router, agents, soul_extractor, llm):
        self.router = router
        self.agents = agents
        self.soul_extractor = soul_extractor
        self.llm = llm
        self.running = True
        self.thread = threading.Thread(target=self._meta_loop, daemon=True)
        self.modification_history = []

    def start(self):
        self.thread.start()

    def stop(self):
        self.running = False

    def _meta_loop(self):
        while self.running:
            time.sleep(30.0)
            if not getattr(self.router, 'collective_chair', False):
                continue
            for agent in self.agents.values():
                comp = self.router.competence[agent.agent_id].get(agent.current_domain, 0.5)
                if comp < 0.4 and SELF_MOD_ENABLED:
                    print(f"[META] Agent {agent.agent_id} has low competence in {agent.current_domain} (comp={comp:.2f})")
                    break

    def propose_modification(self, agent, reason):
        return None