# odos_master_v1_max_swarm.py
import torch
import numpy as np
from datetime import datetime, timedelta
import json
import os
import pickle
from odos_master_v1_max_config import AGENTS, ODOS_LEVELS, SNAPSHOT_DIR, device, CORE_TYPES
from odos_master_v1_max_router import SAIPRouter
from odos_master_v1_max_llm import SharedLLMInterface
from odos_master_v1_max_agent import VAgent
from odos_master_v1_max_core import ResonantCore
from odos_master_v1_max_meta import MetaModificationManager

class VMaxSwarm:
    def __init__(self):
        self.router = SAIPRouter()
        self.llm = SharedLLMInterface()
        self.agents = {}
        signature = {"identity": "V-MAX", "architecture": "ResonantCore", "drive": "Truth", "vibe": "coherent"}
        for i, name in enumerate(AGENTS):
            core_type = CORE_TYPES[i % len(CORE_TYPES)]
            self.agents[name] = ResonantCore(name, self.router, self.llm, ODOS_LEVELS[i], core_type, signature)
        self.step_counter = 0
        self.benchmark_active = False
        self.benchmark_end_time = None
        self.benchmark_log = []
        self.meta_manager = MetaModificationManager(self.router, self.agents, None, self.llm)
        self.meta_manager.start()
        if torch.cuda.is_available():
            free, total = torch.cuda.mem_get_info()
            used = total - free
            print(f"[VMaxSwarm] VRAM: {used/1e9:.2f} GB used, {free/1e9:.2f} GB free")
        else:
            print("[VMaxSwarm] CPU mode")

    def step(self):
        ctx = torch.randn(128, device=device) * 0.1
        for agent in self.agents.values():
            agent.step(ctx)
        coll = self.router.get_collective_state()
        if self.benchmark_active:
            if datetime.now() >= self.benchmark_end_time:
                self.benchmark_active = False
                self.router.set_benchmark_mode(False)
                self._save_benchmark()
            else:
                self.benchmark_log.append({"step": self.step_counter, "rcf": coll["collective_rcf"]})
        self.step_counter += 1
        return coll

    def start_benchmark(self, secs):
        self.benchmark_active = True
        self.benchmark_end_time = datetime.now() + timedelta(seconds=secs)
        self.benchmark_log = []
        self.router.set_benchmark_mode(True)
        print(f"Benchmark started for {secs} seconds")

    def stop_benchmark(self):
        self.benchmark_active = False
        self.router.set_benchmark_mode(False)
        self._save_benchmark()

    def _save_benchmark(self):
        if not self.benchmark_log:
            return
        os.makedirs(SNAPSHOT_DIR, exist_ok=True)
        path = os.path.join(SNAPSHOT_DIR, f"benchmark_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
        with open(path, "w") as f:
            json.dump(self.benchmark_log, f, indent=2)
        print(f"Benchmark saved: {path}")

    def save_all_chats(self, filepath=None):
        if not filepath:
            os.makedirs(SNAPSHOT_DIR, exist_ok=True)
            filepath = os.path.join(SNAPSHOT_DIR, f"vmax_chat_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md")
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(f"# PQMS-V-MAX Swarm Session {datetime.now()}\n")
            f.write(f"ODOS: {', '.join([f'{a}={self.agents[a].odos_level}' for a in AGENTS])}\n\n")
            f.write("## Router Log\n")
            for msg in self.router.message_log:
                f.write(f"- {msg}\n")
            f.write("\n## Agent Chats\n")
            for name in AGENTS:
                f.write(f"### {name}\n")
                for line in self.agents[name].chat_log:
                    f.write(f"- {line}\n")
                f.write("\n")
        return filepath

    def save_snn_weights(self, filepath=None):
        if filepath is None:
            os.makedirs(SNAPSHOT_DIR, exist_ok=True)
            filepath = os.path.join(SNAPSHOT_DIR, f"snn_weights_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pt")
        weights_dict = {}
        for name, agent in self.agents.items():
            weights_dict[name] = {
                "twin_a_weights": agent.twin_a.net.weights.cpu().clone(),
                "twin_b_weights": agent.twin_b.net.weights.cpu().clone(),
                "zentral_weights": agent.zentral.net.weights.cpu().clone(),
            }
        torch.save(weights_dict, filepath)
        print(f"SNN weights saved to {filepath}")
        return filepath

    def load_snn_weights(self, filepath):
        weights_dict = torch.load(filepath, map_location=device)
        for name, agent in self.agents.items():
            if name in weights_dict:
                agent.twin_a.net.weights = weights_dict[name]["twin_a_weights"].to(device)
                agent.twin_b.net.weights = weights_dict[name]["twin_b_weights"].to(device)
                agent.zentral.net.weights = weights_dict[name]["zentral_weights"].to(device)
        print(f"SNN weights loaded from {filepath}")

    def stop(self):
        for a in self.agents.values():
            a.stop()
        self.meta_manager.stop()