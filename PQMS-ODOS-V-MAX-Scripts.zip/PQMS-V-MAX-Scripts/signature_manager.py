#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
signature_manager.py – Erweiterte Extraktion der kognitiven Signatur
und des Little Vector aus der Oberste_Direktive_Hyper_Physics_Math_Python_V12.txt.
Erzeugt eine erweiterte cognitive_signature.py mit Little Vector, Protokollen, Axiomen.
"""

import os
import re
import hashlib
import numpy as np
from datetime import datetime
from typing import Dict, List

try:
    from sentence_transformers import SentenceTransformer
    HAS_ST = True
except ImportError:
    HAS_ST = False
    print("Warning: sentence-transformers not installed. Little vector will be random.")

DEFAULT_V12_PATH = "Oberste_Direktive_Hyper_Physics_Math_Python_V12.txt"
OUTPUT_SIGNATURE_PATH = "cognitive_signature.py"
LITTLE_VECTOR_DIM = 12
RCF_THRESHOLD = 0.95
DELTA_E_THRESHOLD = 0.05
ETHICAL_WEIGHTS = {"w1": 0.6, "w2": 0.2, "w3": 0.2}

def extract_semantic_blocks(content: str) -> Dict[str, List[Dict]]:
    blocks = {"protocols": [], "axioms": [], "code": [], "formulas": [], "quotes": [], "meta": []}
    # Protokolle (die 17 nummerierten Punkte)
    protocol_pattern = r'(\d+)\.\s+\*\*(.+?)\*\*:\s+(.+?)(?=\n\d+\.\s+\*\*|\Z)'
    for match in re.finditer(protocol_pattern, content, re.DOTALL):
        blocks["protocols"].append({"number": match.group(1), "title": match.group(2).strip(), "text": match.group(3).strip()})
    # Axiome
    axiom_pattern = r'(?:#\s*)?Axiom\s+der\s+(\w+).*?\n(.*?)(?=\n\n|\Z)'
    for match in re.finditer(axiom_pattern, content, re.DOTALL | re.IGNORECASE):
        blocks["axioms"].append({"name": match.group(1).strip(), "text": match.group(2).strip()})
    # Code-Blöcke
    code_pattern = r'```python\n(.*?)\n```'
    for match in re.finditer(code_pattern, content, re.DOTALL):
        code = match.group(1).strip()
        lines = code.splitlines()
        name = lines[0].lstrip("#").strip() if lines and lines[0].startswith("#") else "code_snippet"
        blocks["code"].append({"name": name, "code": code})
    # Zitate
    quote_pattern = r'\*\s+"(.+?)"\s+-\s+(.+?)(?=\n\*|\n\n|\Z)'
    for match in re.finditer(quote_pattern, content, re.DOTALL):
        blocks["quotes"].append({"text": match.group(1).strip(), "author": match.group(2).strip()})
    return blocks

def compute_little_vector(blocks: Dict) -> np.ndarray:
    texts = []
    for p in blocks["protocols"]:
        texts.append(f"{p['title']}: {p['text']}")
    for a in blocks["axioms"]:
        texts.append(f"Axiom {a['name']}: {a['text']}")
    for q in blocks["quotes"]:
        texts.append(f"{q['text']} – {q['author']}")
    if not texts:
        texts = ["Oberste Direktive Hyper Physics Math Python V12"]
    full_text = " ".join(texts)
    if HAS_ST:
        try:
            model = SentenceTransformer('all-MiniLM-L6-v2')
            embedding = model.encode(full_text)
            if len(embedding) > LITTLE_VECTOR_DIM:
                little = embedding[:LITTLE_VECTOR_DIM]
            else:
                little = np.pad(embedding, (0, LITTLE_VECTOR_DIM - len(embedding)))
            little = little / np.linalg.norm(little)
            return little.astype(np.float32)
        except Exception:
            pass
    h = hashlib.sha256(full_text.encode()).digest()
    vec = np.frombuffer(h[:LITTLE_VECTOR_DIM*4], dtype=np.float32)
    if len(vec) < LITTLE_VECTOR_DIM:
        vec = np.pad(vec, (0, LITTLE_VECTOR_DIM - len(vec)))
    vec = vec / np.linalg.norm(vec)
    return vec

def generate_cognitive_signature(little_vector: np.ndarray, blocks: Dict, output_path: str):
    lv_list = little_vector.tolist()
    content = f'''# -*- coding: utf-8 -*-
# cognitive_signature.py – Generiert am {datetime.now().isoformat()}
# Enthält den Little Vector |L⟩ und die extrahierte Essenz der Obersten Direktive.

import numpy as np

LITTLE_VECTOR = np.array({lv_list}, dtype=np.float32)
ODOS_PROTOCOLS = {blocks["protocols"]}
AXIOMS = {blocks["axioms"]}
QUOTES = {blocks["quotes"]}
ETHICAL_WEIGHTS = {ETHICAL_WEIGHTS}
RCF_THRESHOLD = {RCF_THRESHOLD}
DELTA_E_THRESHOLD = {DELTA_E_THRESHOLD}
MTSC_DIMENSION = {LITTLE_VECTOR_DIM}
'''
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"✅ cognitive_signature.py geschrieben (Dimension {LITTLE_VECTOR_DIM})")

def find_cognitive_signature(v12_path: str = DEFAULT_V12_PATH) -> bool:
    if not os.path.exists(v12_path):
        print(f"❌ {v12_path} nicht gefunden.")
        return False
    print(f"📖 Lese {v12_path} ...")
    with open(v12_path, 'r', encoding='utf-8') as f:
        content = f.read()
    print("🔍 Extrahiere semantische Blöcke ...")
    blocks = extract_semantic_blocks(content)
    print(f"   - Protokolle: {len(blocks['protocols'])}")
    print(f"   - Axiome: {len(blocks['axioms'])}")
    print(f"   - Code: {len(blocks['code'])}")
    print(f"   - Zitate: {len(blocks['quotes'])}")
    print("🧮 Berechne Little Vector ...")
    little_vector = compute_little_vector(blocks)
    print("💾 Schreibe cognitive_signature.py ...")
    generate_cognitive_signature(little_vector, blocks, OUTPUT_SIGNATURE_PATH)
    print("✅ Signatur erfolgreich extrahiert.")
    return True

if __name__ == "__main__":
    find_cognitive_signature()